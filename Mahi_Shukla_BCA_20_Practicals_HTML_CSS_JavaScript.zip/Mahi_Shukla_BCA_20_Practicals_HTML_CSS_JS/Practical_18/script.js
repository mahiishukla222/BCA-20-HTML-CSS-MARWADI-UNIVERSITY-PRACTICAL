const subjects=[{id:'html',name:'HTML & CSS',detail:'Learn webpage structure, styling, layouts and responsive design.'},{id:'js',name:'JavaScript',detail:'Learn variables, functions, events and dynamic webpage behaviour.'},{id:'dbms',name:'DBMS',detail:'Learn data models, SQL, tables and database management.'},{id:'python',name:'Python',detail:'Learn Python syntax, data structures and programming logic.'}];function showSubject(){let chosen=subjects.find(s=>s.id===subject.value);info.textContent=chosen?chosen.name+': '+chosen.detail:'Subject details will appear here.';}

// Practical 18: Subject information selector
document.addEventListener('DOMContentLoaded', () => {
  const select = document.querySelector('select');
  if (select) select.addEventListener('change', () => {
    const event = new Event('change', {bubbles:true});
    select.dispatchEvent(event);
  });
});
