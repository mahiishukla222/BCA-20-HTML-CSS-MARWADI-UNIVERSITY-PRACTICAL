function getLocation(){const r=document.getElementById('result');if(!navigator.geolocation){r.textContent='Geolocation is not supported by this browser.';return;}r.textContent='Getting location...';navigator.geolocation.getCurrentPosition(p=>{r.textContent='Latitude: '+p.coords.latitude+' | Longitude: '+p.coords.longitude;},e=>{r.textContent='Location unavailable or permission denied: '+e.message;});}

// Practical 10: Geolocation and map helper
document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('showMapLink');
  if (btn) btn.addEventListener('click', () => window.open('https://www.google.com/maps/search/?api=1&query=Marwadi+University+Rajkot','_blank'));
});
