// Practical 04: Subject list navigation
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('a[href^="#"]').forEach(a => a.addEventListener('click', e => {
    const section = document.querySelector(a.getAttribute('href'));
    if (section) { e.preventDefault(); section.scrollIntoView({behavior:'smooth'}); }
  }));
});
