function calculate(){let a=+m1.value,b=+m2.value,c=+m3.value;let vals=[a,b,c];if(vals.some(v=>!Number.isFinite(v)||v<0||v>100)){result.textContent='Enter valid marks between 0 and 100.';return;}let total=a+b+c,per=total/3,grade=per>=90?'A+':per>=80?'A':per>=70?'B':per>=60?'C':per>=40?'D':'F';result.innerHTML='Total: '+total+'/300<br>Percentage: '+per.toFixed(2)+'%<br>Grade: '+grade;}

// Practical 16: Marks calculator
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('marksForm');
  if (form) form.addEventListener('submit', e => { e.preventDefault(); if (typeof calculate === 'function') calculate(); });
});
