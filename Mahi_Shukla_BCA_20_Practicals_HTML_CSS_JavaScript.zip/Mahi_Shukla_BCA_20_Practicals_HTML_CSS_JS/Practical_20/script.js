document.getElementById('contact').addEventListener('submit',e=>{e.preventDefault();document.getElementById('msg').textContent='Thank you. Your message has been recorded.';});

// Practical 20: College website navigation and current year
document.addEventListener('DOMContentLoaded', () => {
  const year = document.getElementById('currentYear');
  if (year) year.textContent = new Date().getFullYear();
  const menu = document.querySelector('.menu-toggle');
  const nav = document.querySelector('nav ul');
  if (menu && nav) menu.addEventListener('click', () => nav.classList.toggle('show'));
});
