// Practical 02: Department page interactions
document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('facultyToggle');
  const list = document.getElementById('facultyList');
  if (btn && list) btn.addEventListener('click', () => {
    list.hidden = !list.hidden;
    btn.textContent = list.hidden ? 'Show Faculty' : 'Hide Faculty';
  });
});
