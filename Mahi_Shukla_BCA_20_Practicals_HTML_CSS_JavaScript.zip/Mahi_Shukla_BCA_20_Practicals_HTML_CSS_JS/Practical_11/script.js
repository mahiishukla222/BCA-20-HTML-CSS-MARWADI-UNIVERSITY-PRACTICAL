// Practical 11: Styled student profile interaction
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('themeToggle');
  if (toggle) toggle.addEventListener('click', () => document.body.classList.toggle('soft-theme'));
});
