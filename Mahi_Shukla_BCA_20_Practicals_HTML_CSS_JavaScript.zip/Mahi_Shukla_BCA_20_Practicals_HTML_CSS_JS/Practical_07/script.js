document.querySelector('form').addEventListener('submit',e=>{e.preventDefault();alert('Registration form submitted successfully!');});

// Practical 07: Registration form validation
document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('form');
  if (form) form.addEventListener('submit', e => {
    if (!form.checkValidity()) { e.preventDefault(); form.reportValidity(); }
  });
});
