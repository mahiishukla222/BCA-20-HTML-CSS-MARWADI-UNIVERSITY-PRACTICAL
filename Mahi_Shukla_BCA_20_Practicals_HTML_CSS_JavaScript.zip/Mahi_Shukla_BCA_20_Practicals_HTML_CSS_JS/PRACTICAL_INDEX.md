# Practical Index

Student: **Shukla Mahi Amitkumar**  
Enrollment No.: **326010020132**

| Practical | Folder | Files |
|---|---|---|
| 1 | `Practical_01/` | HTML + `style.css` + `script.js` |
| 2 | `Practical_02/` | HTML + `style.css` + `script.js` |
| 3 | `Practical_03/` | HTML + `style.css` + `script.js` |
| 4 | `Practical_04/` | HTML + `style.css` + `script.js` |
| 5 | `Practical_05/` | HTML + `style.css` + `script.js` |
| 6 | `Practical_06/` | HTML + `style.css` + `script.js` |
| 7 | `Practical_07/` | HTML + `style.css` + `script.js` |
| 8 | `Practical_08/` | HTML + `style.css` + `script.js` |
| 9 | `Practical_09/` | HTML + `style.css` + `script.js` |
| 10 | `Practical_10/` | HTML + `style.css` + `script.js` |
| 11 | `Practical_11/` | HTML + `style.css` + `script.js` |
| 12 | `Practical_12/` | HTML + `style.css` + `script.js` |
| 13 | `Practical_13/` | HTML + `style.css` + `script.js` |
| 14 | `Practical_14/` | HTML + `style.css` + `script.js` |
| 15 | `Practical_15/` | HTML + `style.css` + `script.js` |
| 16 | `Practical_16/` | HTML + `style.css` + `script.js` |
| 17 | `Practical_17/` | HTML + `style.css` + `script.js` |
| 18 | `Practical_18/` | HTML + `style.css` + `script.js` |
| 19 | `Practical_19/` | HTML + `style.css` + `script.js` |
| 20 | `Practical_20/` | 4 HTML pages + shared `style.css` + `script.js` |
