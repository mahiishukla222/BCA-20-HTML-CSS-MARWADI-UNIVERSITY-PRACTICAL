function checkEligibility(){let a=Number(age.value),att=Number(attendance.value),m=Number(marks.value);if(!age.value||!attendance.value||!marks.value||a<=0||att<0||att>100||m<0||m>100){status.textContent='Please enter valid values.';return;}if(a>=17&&att>=75&&m>=40){status.textContent='Eligible for examination / admission.';alert('Congratulations! You are eligible.');}else{status.textContent='Not eligible. Check age, attendance and marks criteria.';alert('You are not eligible yet.');}}

// Practical 17: Student eligibility checker
document.addEventListener('DOMContentLoaded', () => {
  const fields = document.querySelectorAll('input[type=number]');
  fields.forEach(input => input.addEventListener('input', () => {
    if (input.value !== '' && Number(input.value) < 0) input.value = 0;
  }));
});
