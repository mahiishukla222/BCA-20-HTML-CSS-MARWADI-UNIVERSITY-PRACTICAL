# BCA 20 Practicals — HTML, CSS & JavaScript

**Student:** Shukla Mahi Amitkumar  
**Enrollment No.:** 326010020132  
**Programme:** Bachelor of Computer Applications (BCA) – Online  
**Faculty:** Faculty of Computer Applications, Marwadi University

## Project structure
- `Practical_01` through `Practical_19`: each folder contains one HTML file, `style.css`, and `script.js`.
- `Practical_20`: a multi-page college website with `index.html`, `about.html`, `courses.html`, `contact.html`, one shared `style.css`, and one shared `script.js`.

## How to run each practical
1. Extract the ZIP file.
2. Open the required Practical folder.
3. Keep the HTML, CSS and JavaScript files together in that folder.
4. Double-click the HTML file to open it in Chrome, Edge or Firefox.
5. For Practical 20, open `Practical_20/index.html`.

## GitHub upload
1. Sign in at https://github.com/.
2. Create a **Public** repository, e.g. `BCA-20-HTML-CSS-JavaScript-Practicals`.
3. Upload the contents of this folder (all 20 Practical folders plus README.md), not the ZIP file itself.
4. Commit the files. Keep the repository URL for assignment submission.
5. If the teacher specifically asks for a live website URL, use **Settings → Pages** and publish from the selected branch/folder. A repository URL and a live GitHub Pages URL are different.

## Before submission
Run each practical in a browser, verify all links and interactive features, and understand the code. Update any sample content or placeholders to match your own details. Follow the teacher's instructions about commits and submission.
