document.getElementById('reg').addEventListener('submit',function(e){e.preventDefault();let errors=[];if(name.value.trim().length<3)errors.push('Name must contain at least 3 characters.');if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.value))errors.push('Enter a valid email.');if(password.value.length<6)errors.push('Password must be at least 6 characters.');if(!gender.value)errors.push('Select gender.');if(!/^[0-9]{10}$/.test(mobile.value))errors.push('Mobile number must contain 10 digits.');message.textContent=errors.length?errors.join(' '):'Registration details validated successfully!';if(errors.length)alert('Please correct the form errors.');else alert('Registration successful!');});

// Practical 19: Registration validation helper
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('input').forEach(input => {
    input.addEventListener('input', () => input.classList.toggle('valid-field', input.checkValidity()));
  });
});
