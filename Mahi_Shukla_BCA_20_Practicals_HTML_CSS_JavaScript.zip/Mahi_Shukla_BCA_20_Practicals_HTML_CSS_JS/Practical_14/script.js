// Practical 14: Restaurant menu search and category filtering
document.addEventListener('DOMContentLoaded', () => {
  const search = document.getElementById('menuSearch');
  if (search) search.addEventListener('input', () => {
    document.querySelectorAll('[data-menu-item]').forEach(item => {
      item.hidden = !item.textContent.toLowerCase().includes(search.value.toLowerCase());
    });
  });
});
