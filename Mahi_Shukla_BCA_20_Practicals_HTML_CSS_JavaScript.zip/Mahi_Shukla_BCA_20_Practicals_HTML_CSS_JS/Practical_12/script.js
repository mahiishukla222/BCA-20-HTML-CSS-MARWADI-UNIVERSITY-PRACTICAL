document.getElementById('admission').addEventListener('submit',e=>{e.preventDefault();document.getElementById('msg').textContent='Your admission application is ready for submission.';});

// Practical 12: Admission form helper
document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('form');
  if (form) form.addEventListener('reset', () => {
    const msg = document.getElementById('msg');
    if (msg) msg.textContent = 'Form has been reset.';
  });
});
