// Practical 03: Event page interactions
document.addEventListener('DOMContentLoaded', () => {
  const countdown = document.getElementById('eventCountdown');
  if (countdown) countdown.textContent = 'Registration is open!';
  const eventLink = document.querySelector('[data-event-register]');
  if (eventLink) eventLink.addEventListener('click', () => alert('You are being redirected to the event registration page.'));
});
