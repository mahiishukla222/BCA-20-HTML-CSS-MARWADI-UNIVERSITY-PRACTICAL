// Practical 08: Event media controls
document.addEventListener('DOMContentLoaded', () => {
  const media = document.querySelector('video, audio');
  const btn = document.getElementById('mediaStatus');
  if (media && btn) btn.addEventListener('click', () => {
    btn.textContent = media.paused ? 'Media is paused' : 'Media is playing';
  });
});
