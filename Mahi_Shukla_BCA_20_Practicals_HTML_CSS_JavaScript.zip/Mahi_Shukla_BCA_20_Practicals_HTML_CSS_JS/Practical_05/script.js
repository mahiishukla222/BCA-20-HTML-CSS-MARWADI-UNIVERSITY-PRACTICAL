// Practical 05: Student profile navigation and print
document.addEventListener('DOMContentLoaded', () => {
  const printBtn = document.getElementById('printProfile');
  if (printBtn) printBtn.addEventListener('click', () => window.print());
  document.querySelectorAll('a[href^="#"]').forEach(a => a.addEventListener('click', () => {
    const section = document.querySelector(a.getAttribute('href'));
    if (section) section.classList.add('section-highlight');
  }));
});
