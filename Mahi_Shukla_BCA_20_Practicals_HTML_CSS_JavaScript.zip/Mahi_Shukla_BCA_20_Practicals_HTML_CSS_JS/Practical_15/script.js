function changeWatch(){const w=document.getElementById('watch');w.textContent=w.textContent==='⌚'?'⌚':'⌚';w.style.background='linear-gradient(135deg,#ffe2b9,#d8e8ff)';alert('Product image style updated.');}

// Practical 15: Product showcase interactions
document.addEventListener('DOMContentLoaded', () => {
  let count = 0;
  const button = document.getElementById('addToCart');
  const badge = document.getElementById('cartCount');
  if (button) button.addEventListener('click', () => {
    count++; if (badge) badge.textContent = count;
    button.textContent = 'Added ✓';
    setTimeout(() => button.textContent = 'Add to Cart', 900);
  });
});
