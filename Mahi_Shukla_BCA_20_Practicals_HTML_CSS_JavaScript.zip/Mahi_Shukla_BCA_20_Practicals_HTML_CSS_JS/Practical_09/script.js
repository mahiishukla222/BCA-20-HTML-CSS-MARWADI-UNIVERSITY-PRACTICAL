const c=document.getElementById('art'),x=c.getContext('2d');x.fillStyle='#e65f35';x.fillRect(30,30,130,80);x.beginPath();x.arc(260,80,50,0,Math.PI*2);x.fillStyle='#3b8c72';x.fill();x.beginPath();x.moveTo(390,120);x.lineTo(470,25);x.lineTo(550,120);x.strokeStyle='#263b67';x.lineWidth=5;x.stroke();x.font='24px Arial';x.fillStyle='#202533';x.fillText('HTML5 Canvas',30,210);

// Practical 09: Canvas drawing interaction
document.addEventListener('DOMContentLoaded', () => {
  const canvas = document.querySelector('canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  canvas.addEventListener('click', e => {
    const r = canvas.getBoundingClientRect();
    const x = (e.clientX-r.left) * canvas.width/r.width;
    const y = (e.clientY-r.top) * canvas.height/r.height;
    ctx.beginPath(); ctx.arc(x,y,7,0,Math.PI*2); ctx.fillStyle='#e65f35'; ctx.fill();
  });
});
