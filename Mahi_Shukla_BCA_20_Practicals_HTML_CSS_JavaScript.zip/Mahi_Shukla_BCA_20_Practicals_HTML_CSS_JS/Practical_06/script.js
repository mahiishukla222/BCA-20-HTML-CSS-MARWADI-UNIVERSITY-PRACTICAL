// Practical 06: Student marks table total and percentage
document.addEventListener('DOMContentLoaded', () => {
  const table = document.querySelector('table');
  const output = document.getElementById('tableSummary');
  if (table && output) {
    const rows = [...table.querySelectorAll('tbody tr')];
    output.textContent = `${rows.length} student record(s) displayed.`;
  }
});
