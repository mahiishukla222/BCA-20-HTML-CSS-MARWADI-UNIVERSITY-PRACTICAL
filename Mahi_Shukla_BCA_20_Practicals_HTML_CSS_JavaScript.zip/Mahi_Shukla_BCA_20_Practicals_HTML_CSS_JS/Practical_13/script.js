// Practical 13: Responsive college website
document.addEventListener('DOMContentLoaded', () => {
  const year = document.getElementById('currentYear');
  if (year) year.textContent = new Date().getFullYear();
  document.querySelectorAll('.navbar a').forEach(a => a.addEventListener('click', () => {
    const nav = document.querySelector('.navbar-collapse.show');
    if (nav && window.bootstrap) bootstrap.Collapse.getOrCreateInstance(nav).hide();
  }));
});
